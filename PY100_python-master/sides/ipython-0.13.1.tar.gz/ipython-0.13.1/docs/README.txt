Current version information
---------------------------

Please open manual.pdf for a PDF version of IPython's user manual, or go to
the manual/ directory for an HTML version.


Bugs and future developments
----------------------------

The new_design.pdf document is a description of the goals for IPython's future
development.  It includes a TODO/bugs section listing all currently known bugs
in IPython.  Please report any bug you encounter if it is not already listed
there.
